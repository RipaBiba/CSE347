from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import path, include
#from users import views as user_views
from django.conf import settings
from django.conf.urls.static import static
from . import views

app_name = 'store'

urlpatterns = [
    path('', views.product_all, name ='product_all'),
    path('<slug:slug>/', views.product_detail, name = "product_detail"),
    path('shop/<slug:category_slug>/', views.category_list, name='category_list'),

]





if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)