from django.contrib import admin
from .models import Category, Product

# Register your models here.

admin.site.register(Category)
#admin.site.register(Product)

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ['title', 'author', 'slug', 'price', 'in_stock',
    'created', 'updated']
    list_filter = ['in_stock', 'in_active']
    list_editable = ['price', 'in_stock']
    prepopulated_fields = {'slug': ('title', )}
