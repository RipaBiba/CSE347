from django.shortcuts import redirect, render, get_object_or_404
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.contrib.auth.models import User
from django.urls import reverse
from django.views.generic import (
    ListView, DetailView, 
    CreateView, UpdateView, DeleteView
)
from datetime import datetime
from django.contrib import messages
from basket.basket import Basket
from .forms import *
from .models import *



def home(request):
    return render(request, 'home/home.html',{'title': 'Home'})

def page(request):
    context = {
        'posts': Post.objects.all()
    }
    return render(request, 'home/blog.html', context)


class PostListView(ListView):
    model = Post
    template_name = 'home/blog.html'#<app>/<model>_<viewtype>.html
    context_object_name = 'posts'
    ordering = ['-date_posted']
    paginate_by = 5


class UserPostListView(ListView):
    model = Post
    template_name = 'home/user_posts.html'#<app>/<model>_<viewtype>.html
    context_object_name = 'posts'
    paginate_by = 5

    def get_queryset(self):
        user = get_object_or_404(User, username = self.kwargs.get('username'))
        return Post.objects.filter(author = user).order_by('-date_posted')



class PostDetailView(DetailView):
    model = Post

    def get_context_data(self, *args, **kwargs):
        #cat_menu = Category.objects.all()
        context = super(PostDetailView, self).get_context_data(*args, **kwargs)
        stuff = get_object_or_404(Post, id=self.kwargs.get('pk'))
        total_likes = stuff.total_likes()
        #context["cat_menu"] = cat_menu

        liked = False
        if stuff.likes.filter(id = self.request.user.id).exists():
            liked = True

        context["total_likes"] = total_likes
        context["liked"] = liked
        
        return context


class PostCreateView(LoginRequiredMixin, CreateView):
    model = Post
    #fields = ['title', 'content']
    form_class = PostForm

    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)


class PostCategoryView(LoginRequiredMixin, CreateView):
    model = PostCategory
    # fields = ['title', 'content', 'image']
    #form_class = PostForm
    template_name = 'home/add_post_category.html'
    fields = '__all__'


class PostUpdateView(LoginRequiredMixin,UserPassesTestMixin, UpdateView):
    model = Post
    #fields = ['title', 'content', 'post_category']
    form_class = PostUpdateForm

    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)

    def test_func(self):
        post = self.get_object()
        if self.request.user == post.author:
            return True
        return False


class PostDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Post
    success_url = '/'

    def test_func(self):
        post = self.get_object()
        if self.request.user == post.author:
            return True
        return False


def PostCategoryListView(request):
    cat_menu_list = PostCategory.objects.all()
    return render(request, 'home/post_category_list.html', {'cat_menu_list': cat_menu_list})


def PostCategoriesView(request, cats):
    category_posts = Post.objects.filter(post_category=cats.replace('-',' '))
    return render(request, 'home/post_categories.html', {'cats': cats.title().replace('-',' '), 'category_posts': category_posts})


def LikeView(request, pk):
    post = get_object_or_404(Post, id = request.POST.get('post_id'))
    liked = False

    if post.likes.filter(id = request.user.id).exists():
        post.likes.remove(request.user)
        liked = False
    else:
        post.likes.add(request.user)
        liked = True
    return HttpResponseRedirect(reverse('post_detail', args=[str(pk)]))


class AddPostCommentView(CreateView):
    model =  PostComment
    form_class = PostCommentForm


    def form_valid(self, form):
        form.instance.post_id = self.kwargs['pk']
        form.instance.user = self.request.user
        item = form.save()
        self.id = self.kwargs['pk']
        return super().form_valid(form)

    def get_success_url(self):
         #print(self.pk)
         return reverse('post_detail', kwargs={'pk': self.id})


def product(request):
    context = {
        'products': Product.objects.all()
    }
    print(context)
    return render(request, 'home/product.html', context)



class UserProductListView(ListView):
    model = Product
    template_name = 'home/user_products.html'#<app>/<model>_<viewtype>.html
    context_object_name = 'products'
    paginate_by = 3

    def get_queryset(self):
        user = get_object_or_404(User, username = self.kwargs.get('username'))
        return Product.objects.filter(seller = user).order_by('-date_posted')


class ProductListView(ListView):
    model = Product
    template_name = 'home/product.html'#<app>/<model>_<viewtype>.html
    context_object_name = 'products'
    ordering = ['-date_posted']
    paginate_by = 4



class ProductDetailView(DetailView):
    model = Product


class ProductCreateView(LoginRequiredMixin, CreateView):
    model = Product
    #fields = ['name', 'price', 'category']
    form_class = ProductForm

    def form_valid(self, form):
        form.instance.seller = self.request.user
        return super().form_valid(form)


class ProductCategoryView(LoginRequiredMixin, CreateView):
    model = ProductCategory
    template_name = 'home/add_product_category.html'
    fields = '__all__'


class ProductUpdateView(LoginRequiredMixin,UserPassesTestMixin, UpdateView):
    model = Product
    #fields = ['new_price', 'status']
    form_class = ProductUpdateForm

    def form_valid(self, form):
        form.instance.seller = self.request.user
        return super().form_valid(form)

    def test_func(self):
        product = self.get_object()
        if self.request.user == product.seller:
            return True
        return False


class ProductDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Product
    success_url = '/'

    def test_func(self):
        product = self.get_object()
        if self.request.user == product.seller:
            return True
        return False


def ProductCategoryListView(request):
    cat_menu_list = ProductCategory.objects.all()
    return render(request, 'home/product_category_list.html', {'cat_menu_list': cat_menu_list})


def ProductCategoriesView(request, cats):
    category_posts = Product.objects.filter(category=cats.replace('-',' '))
    return render(request, 'home/product_categories.html', {'cats': cats.title().replace('-',' '), 'category_posts': category_posts})


def ProductStatusView(request, stas):
    status_posts = Product.objects.filter(status=stas.replace('-',' '))
    return render(request, 'home/product_status.html', {'stas': stas.title().replace('-',' '), 'status_posts': status_posts})


def ProductStatusListView(request):
    stas_menu_list = ProductStatus.objects.all()
    return render(request, 'home/product_status_list.html', {'stas_menu_list': stas_menu_list})


class AddProductCommentView(CreateView):
    model =  ProductComment
    form_class = ProductCommentForm


    def form_valid(self, form):
        form.instance.product_id = self.kwargs['pk']
        form.instance.user = self.request.user
        item = form.save()
        self.id = self.kwargs['pk']
        return super().form_valid(form)

    def get_success_url(self):
         #print(self.pk)
         return reverse('product_detail', kwargs={'pk': self.id})
         

def about(request):
    return render(request, 'home/about.html', {'title': 'About'})


def announcements(request):
    return render(request, 'home/announcements.html', {'title': 'Announcements'})


def contact(request):
    #return HttpResponse("This is contact")
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        mobile = request.POST.get('mobile')
        desk = request.POST.get('desk')
        contact = Contact(name=name,first_name = first_name, last_name = last_name, email= email, mobile = mobile, desk= desk, date= datetime.today())
        contact.save()
        messages.success(request, 'Your message has been sent... We will Connect you soon...')

    return render(request, 'home/contact.html')


class ContactListView(ListView):
    model = Contact
    template_name = 'home/contact_lists.html'#<app>/<model>_<viewtype>.html
    context_object_name = 'contacts'
    paginate_by = 5


def order(request):
    basket = Basket(request)
    baskettotal = basket.get_total_price()
    print(basket)
    user = request.user
    for item in basket:
        order_item = Order(user = user,product=item['product'], price=item['price'], new_price=item['new_price'], total_price=baskettotal, quantity=item['qty'])
        order_item.save()
    messages.success(request, 'Your Order has been Placed!')
    print(basket)

    return redirect('checkout')

class OrderSummeryListView(ListView):
    model = Order
    template_name = 'home/order_summery.html'#<app>/<model>_<viewtype>.html
    context_object_name = 'orders'
    paginate_by = 2

    def get_queryset(self):
        user = get_object_or_404(User, username = self.kwargs.get('username'))
        return Order.objects.filter(user = user)


class AllOrderView(ListView):
    model = Order
    template_name = 'home/all_order.html'#<app>/<model>_<viewtype>.html
    context_object_name = 'orders'
    paginate_by = 2


class CheckoutView(LoginRequiredMixin, CreateView):
    model = Checkout
   # fields = ['new_price']
    form_class = CheckoutForm
    success_url = '/'

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)


def wishlist(request):
    basket = Basket(request)
    user = request.user
    for item in basket:
        wishlist = WishList(user = user,product=item['product'])
        wishlist.save()
    messages.success(request, 'Product has been stored in your wishlist!')

    return redirect('profile')


def addwishlist(request):
    nid = request.GET.get('product_id')
    #list_ = WishList.objects.filter(user = request.user)
    newwatchlist = WishList(user = request.user, product = Product.objects.get(pk = nid))
    newwatchlist.save()
    messages.success(request, "Product added to Your Watchlist")
    return redirect('profile')


class WishListView(ListView):
    model = WishList
    template_name = 'home/wishlist.html'#<app>/<model>_<viewtype>.html
    context_object_name = 'wishlists'
    paginate_by = 2

    def get_queryset(self):
        user = get_object_or_404(User, username = self.kwargs.get('username'))
        return WishList.objects.filter(user = user)


class WishListDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = WishList
    success_url = '/'

    def test_func(self):
        wishlist = self.get_object()
        if self.request.user == wishlist.user:
            return True
        return False


class PlaceBidView(CreateView):
    model =  Bid
    form_class = PlaceBidForm

    def form_valid(self, form):
        form.instance.product_id = self.kwargs['pk']
        form.instance.user = self.request.user
        item = form.save()
        self.id = self.kwargs['pk']
        return super().form_valid(form)

    def get_success_url(self):
         #print(self.pk)
         messages.success(self.request, "Your Bid has been Placed Successfully!")
         return reverse('product_detail', kwargs={'pk': self.id})


class BidListView(ListView):
    model = Bid
    template_name = 'home/bid_summery.html'#<app>/<model>_<viewtype>.html
    context_object_name = 'bid_lists'
    paginate_by = 2

    def get_queryset(self):
        user = get_object_or_404(User, username = self.kwargs.get('username'))
        return Bid.objects.filter(user = user)


class BidListUpdateView(LoginRequiredMixin,UserPassesTestMixin, UpdateView):
    model = Bid
    form_class = BidUpdateForm
    success_url = '/'

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)

    def test_func(self):
        bid = self.get_object()
        if self.request.user == bid.user:
            return True
        return False


class BidListDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Bid
    success_url = '/'

    def test_func(self):
        bid = self.get_object()
        if self.request.user == bid.user:
            return True
        return False


def terms_use(request):
    return render(request, 'home/terms_use_privacy.html', {'title': 'terms_use'})
    

def features(request):
    return render(request, 'home/features.html', {'title': 'features'})


def agreement(request):
    return render(request, 'home/agreement.html', {'title': 'agreement'})


def faqs(request):
    return render(request, 'home/faqs.html', {'title': 'faqs'})


def subscription(request):
    return render(request, 'home/subscription.html', {'title': 'subscription'})


def help(request):
    return render(request, 'home/help.html', {'title': 'help'})


def tips(request):
    return render(request, 'home/tips.html', {'title': 'tips'})


def calendars(request):
    return render(request, 'home/calendars.html', {'title': 'calendars'})

def help1(request):
    return render(request, 'home/help1.html', {'title': 'Help1'})

def help2(request):
    return render(request, 'home/help2.html', {'title': 'Help2'})

def help3(request):
    return render(request, 'home/help3.html', {'title': 'Help3'})

def help4(request):
    return render(request, 'home/help4.html', {'title': 'Help4'})

def help5(request):
    return render(request, 'home/help5.html', {'title': 'Help5'})

def help6(request):
    return render(request, 'home/help6.html', {'title': 'Help6'})