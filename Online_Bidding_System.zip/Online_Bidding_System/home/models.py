from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django_countries.fields import CountryField
from phonenumber_field.modelfields import PhoneNumberField
from django.urls import reverse
from PIL import Image



# Create your models here.
##table create code likhte hobe

class Contact(models.Model):
    name = models.CharField(max_length=120)
    first_name = models.CharField(max_length=120)
    last_name = models.CharField(max_length=120)
    mobile = PhoneNumberField(default="+8801420420420", blank=True, max_length=14, region=None)
    desk = models.TextField()
    date = models.DateField()
    email= models.CharField(default= 'example@gmail.com',null=False, max_length=200)

    def __str__(self):
        return self.name

    def save(self):
        super().save()
        
class PostCategory(models.Model):
        name = models.CharField(max_length=150)

        def __str__(self):
            return self.name

        def get_absolute_url(self):
            return reverse('blog')


class Post(models.Model):
    title = models.CharField(max_length=150)
    title_tag = models.CharField(max_length=150, default="Blog!")
    image = models.ImageField(default='default.jpg', upload_to='pictures/')
    content = models.TextField()
    post_category = models.CharField(max_length=150, default="uncategorized!")
    date_posted = models.DateTimeField(default=timezone.now)
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    likes = models.ManyToManyField(User, related_name='blog_posts')

    def total_likes(self):
        return self.likes.count()

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        super(Post, self).save(*args, **kwargs)

        img = Image.open(self.image.path)

        if img.height > 300 or img.width > 300:
            output_size = (300, 300)
            img.thumbnail(output_size)
            img.save(self.image.path)

    def get_absolute_url(self):
        return reverse('post_detail', kwargs = {'pk': self.pk})


class PostComment(models.Model):
    post = models.ForeignKey(Post, related_name="post_comments", on_delete=models.CASCADE)    
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    image = models.ImageField(null=True, blank=True, upload_to='comment')
    body = models.TextField()
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return '%s comment on %s' % (self.user, self.post.title)
       

class ProductCategory(models.Model):
        name = models.CharField(max_length=150)

        def __str__(self):
            return self.name

        def get_absolute_url(self):
            return reverse('home')

class ProductStatus(models.Model):
        status = models.CharField(max_length=150)

        def __str__(self):
            return self.status

        def get_absolute_url(self):
            return reverse('home')


class ProductManager(models.Manager):
    def get_queryset(self):
        return super(ProductManager, self).get_queryset().filter(in_active = True)


class Product(models.Model):
    name = models.CharField(max_length=100)
    price = models.DecimalField(max_digits=15,decimal_places=6)
    new_price = models.DecimalField(default = 0, max_digits=15,decimal_places=6)
    category = models.CharField(max_length=200)
    status = models.CharField(default= 'stored', max_length=200)
    date_posted = models.DateTimeField(default=timezone.now)
    seller = models.ForeignKey(User, on_delete=models.CASCADE)
    desc = models.TextField(blank = True)  
    starting_bid = models.IntegerField(default = 0)        
    in_stock = models.BooleanField(default = True)
    in_active = models.BooleanField(default = True)
    image = models.ImageField(default='default.jpg', upload_to='images/')
    created = models.DateTimeField(default=timezone.now)
    updated = models.DateTimeField(default=timezone.now)
    objects = models.Manager()
    products = ProductManager()

    class Meta:
        verbose_name_plural = 'Products'
        ordering = ('-created',)

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        super(Product, self).save(*args, **kwargs)

        img = Image.open(self.image.path)

        if img.height > 300 or img.width > 300:
            output_size = (300, 300)
            img.thumbnail(output_size)
            img.save(self.image.path)

    def get_absolute_url(self):
        return reverse('product_detail', kwargs = {'pk': self.pk})


class ProductComment(models.Model):
    product = models.ForeignKey(Product, related_name="product_comments", on_delete=models.CASCADE)    
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    image = models.ImageField(null=True, blank=True, upload_to='comment')
    body = models.TextField()
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return '%s comment on %s' % (self.user.username, self.product.name)


class Order(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    price = models.DecimalField(max_digits=15, decimal_places=6)
    new_price = models.DecimalField(default=0, max_digits=15, decimal_places=6)
    total_price = models.DecimalField(default=0, max_digits=15, decimal_places=6)
    quantity = models.PositiveIntegerField(default=1)
    
    def __str__(self):
        return f"{self.quantity} of {self.product.name}"

    def save(self):
        super().save()


class Checkout(models.Model):
    PAYMENT_CHOICES = (
        ('Cash', 'Cash on Delivery'),
        ('Bkash', 'Bkash'),
        ('Card', 'Card'),
    )
    BILL_CHOICES = (
        ('Pending', 'Yet Pending'),
        ('Paid', 'Paid Done'),
    )
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    address = models.CharField(default='please enter full address',max_length=250,null=False)
    country = CountryField(default='Select country',blank_label='(Select country)')
    ordered = models.BooleanField(default=False)
    city = models.CharField(max_length=100,null=False)
    post_code = models.CharField(max_length=20,null=False,)
    date = models.DateTimeField(auto_now_add=True)
    advance_paid = models.BooleanField(blank=True,default=False)
    bill_status = models.CharField(default='Select',max_length=10, choices=BILL_CHOICES)
    full_name = models.CharField(default='name', max_length=120)
    mobile = PhoneNumberField(default="+8801420420420", blank=False, max_length=14, region=None)
    alter_mobile = PhoneNumberField(default="+8801420420420", blank=True, max_length=14, region=None)
    email= models.CharField(default= 'example@gmail.com',null=False, max_length=200)
    payment_option = models.CharField(max_length=10, choices=PAYMENT_CHOICES)

    def __str__(self):
        return f"{self.user.username} checkout {self.order.product.name}"

    def save(self):
        super().save()	


class WishList(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} wish {self.product.name}"

    def save(self):
        super().save()


class Bid(models.Model):
    product = models.ForeignKey(Product, related_name="bids", on_delete=models.CASCADE)    
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    ammount = models.IntegerField()
    text_message = models.TextField()
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return '%s placed bid on %s' % (self.user.username, self.product.name)
