from django import forms
from .models import *

choices1= PostCategory.objects.all().values_list('name','name')
choices2= ProductCategory.objects.all().values_list('name','name')
choices3= ProductStatus.objects.all().values_list('status','status')


choice_list = []
nothing = []

def choice(choice):
    choice_list = list(nothing)
    for item in choice:
         choice_list.append(item)
    return choice_list

list1 = choice(choices1)
print(list1)
list2 = choice(choices2)
print(list2)
list3 = choice(choices3)
print(list3)



class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ('title','title_tag','post_category', 'content', 'image')

        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'title_tag': forms.TextInput(attrs={'class': 'form-control'}),
            'post_category': forms.Select(choices = list1, attrs={'class': 'form-control'}),
            'content': forms.Textarea(attrs={'class': 'form-control'}),
        }


class PostUpdateForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ('title_tag','post_category', 'content', 'image')

        widgets = {
            'title_tag': forms.TextInput(attrs={'class': 'form-control'}),
            'post_category': forms.Select(choices = list1, attrs={'class': 'form-control'}),
            'content': forms.Textarea(attrs={'class': 'form-control'}),
        }


class PostCommentForm(forms.ModelForm):
    class Meta:
        model = PostComment
        fields = ('body', 'image')

        widgets = {
            'body': forms.Textarea(attrs={'class': 'form-control'}),
        }


class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ('name', 'price','starting_bid', 'category', 'status', 'image')

        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'category': forms.Select(choices = list2, attrs={'class': 'form-control'}),
            'price': forms.NumberInput(attrs={'class': 'form-control'}),
            'starting_bid': forms.NumberInput(attrs={'class': 'form-control'}),
            'status': forms.Select(choices = list3, attrs={'class': 'form-control'}),
        }


class ProductUpdateForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ('new_price', 'starting_bid', 'status', 'image')

        widgets = {
            'new_price': forms.NumberInput(attrs={'class': 'form-control'}),
            'starting_bid': forms.NumberInput(attrs={'class': 'form-control'}),
            'status': forms.Select(choices = list3, attrs={'class': 'form-control'}),
        }


class ProductCommentForm(forms.ModelForm):
    class Meta:
        model = ProductComment
        fields = ('body', 'image')

        widgets = {
            'body': forms.Textarea(attrs={'class': 'form-control'}),
        }
        

class CheckoutForm(forms.ModelForm):
    class Meta:
        model = Checkout
        exclude = ('user',)
        #fields = ('user','first_name', 'last_name', 'mobile', 'desk')
        fields = '__all__'
       

class PlaceBidForm(forms.ModelForm):
    class Meta:
        model = Bid
        fields = ('ammount', 'text_message')

        widgets = {
            'ammount': forms.NumberInput(attrs={'class': 'form-control'}),
            'text_message': forms.Textarea(attrs={'class': 'form-control'}),
        }   


class BidUpdateForm(forms.ModelForm):
    class Meta:
        model = Bid
        fields = ('text_message',)

        widgets = {
            'text_message': forms.Textarea(attrs={'class': 'form-control'}),
        }