from xml.dom.pulldom import PROCESSING_INSTRUCTION
from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(Post)
#admin.site.register(Product)

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ['name', 'seller', 'price','new_price', 'in_stock',
    'created', 'updated']
    list_filter = ['in_stock', 'in_active']
    list_editable = ['price', 'in_stock']
    #prepopulated_fields = {'slug': ('name', )}

admin.site.register(Contact)
admin.site.register(PostCategory)
admin.site.register(PostComment)
admin.site.register(ProductCategory)
admin.site.register(ProductStatus)
admin.site.register(ProductComment)
admin.site.register(Order)
admin.site.register(Checkout)
admin.site.register(WishList)
admin.site.register(Bid)